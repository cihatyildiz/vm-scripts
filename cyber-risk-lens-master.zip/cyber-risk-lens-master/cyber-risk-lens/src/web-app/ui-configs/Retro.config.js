export const config = {
        color_1: '#030B35',
        color_2: '#141C41',
        color_3: '#5CCD98',
        color_4: '#F7BA44',
        color_5: '#ED3F5A',
        color_6: '#60D7E9',
        color_7: '#2E7EAA',
        color_8: '#FFFFFF',
        color_9: '#EB5757',
        color_10: '#F2994A',
        color_11: '#F2C94C',
        color_12: '#2D9CDB',
        color_13: ' #56CCF2',
        color_16: '#e0e0e0'
}
