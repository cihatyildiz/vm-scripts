export default {
  apps: { name: 'Apps', link: '/eagle-eye/apps' },
  Vulnerabilities: { name: 'Vulnerabilities', link:'/eagle-eye/vulns'}

}
