export default {
  users: { name: 'Users', link: '/platform/users/list' },
  groups: {name: 'Groups', link:'/platform/user-groups/list'}
}
