export default {
  users: { name: 'Users', link: '/platform/users/list' },
  userGroups: { name: 'User Groups', link: '/platform/user-groups/list' }
}
