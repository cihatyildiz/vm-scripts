import React from "react";
import Badge from "@material-ui/core/Badge";


function MaterialBadge(props) {
  return <Badge {...props} />;
}


export default MaterialBadge;
