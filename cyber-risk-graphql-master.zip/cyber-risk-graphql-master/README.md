# cyber-risk-graphql
### STEP 1: git pull
### STEP 2: docker-compose up -d --build
### STEP 3: docker exec -it cyber-risk-graphql bash
### STEP 4: node src/index.js
