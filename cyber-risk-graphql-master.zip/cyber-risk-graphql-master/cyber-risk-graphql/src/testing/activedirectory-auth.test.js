// Initialize - This Works !
var ActiveDirectory = require('activedirectory');
var config = {
    url: 'ldap://deltads-ads-vip.deltads.ent:389',
    baseDN: 'dc=deltads,dc=ent'
};
var ad = new ActiveDirectory(config);
var username = '';
var password = '';
// Authenticate code
ad.authenticate(username, password, function(err, auth) {
    if (err) {
        console.log('ERROR: '+JSON.stringify(err));
        return;
    }
    if (auth) {
        console.log('Authenticated!');
    }
    else {
        console.log('Authentication failed!');
    }
});
