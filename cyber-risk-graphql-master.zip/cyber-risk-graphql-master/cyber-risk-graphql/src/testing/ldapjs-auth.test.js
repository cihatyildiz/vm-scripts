var ldap = require('ldapjs');

function authDN(dn, password, cb) {
  var client = ldap.createClient({url: 'ldap://deltads-ads-vip.deltads.ent:389'});
  client.bind(dn, password, function (err) {
    client.unbind();
    cb(err === null, err);
  });
}


function output(res, err) {
  if (res) {
    console.log('success');
  } else {
    console.log('failure');
  }
}

// should print "success"
// authDN('cn=user', 'goodpasswd', output);
authDN('CN=Pankaj Moolrajani,OU=CA-Users,OU=Prod_Users,OU=Users,OU=Enterprise,DC=deltads,DC=ent', '', output)

// should print "failure"
// authDN('cn=user', 'badpasswd', output);