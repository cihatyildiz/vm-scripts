require( 'module-alias/register' )
const Express = require( "express" );
const ExpressGraphQL = require("express-graphql");
const GraphQLSchema = require("graphql").GraphQLSchema;
const cors = require("cors")
const queries = require('./schema/queries')
const mutations = require('./schema/mutations')


var app = Express();
app.use(cors())


const schema = new GraphQLSchema({
  query: queries,
  mutation: mutations
});


function authorize(req, res) {
  try {
    if (
      'accesstoken' in req.headers
      && req.headers.accesstoken === 'a769ab58405942d1b57365a1f0f48ea4'
    ) {
      return true
    }
  } catch (err) {
    console.log(err)
  }
  return false
}


app.use(
  '/graphql',
  async (req, res) => {
    try {
      const isAuthorized = authorize(req, res)
      if (isAuthorized) {
        return ExpressGraphQL({
          schema: schema,
          graphiql: true,
          context: {req, res}
        })(req, res)
      }
    } catch (err) {
      console.log(err)
    }
    res.status(401).send('Unauthorized')
  }
);


app.listen(8080, () => {
  console.log("Listening at :8080...");
});
