const GraphQLObjectType = require('graphql').GraphQLObjectType
const cronJobById = require('@platform/cronJob/cronJobById.query')
const cronJobBySearch = require('@platform/cronJob/cronJobBysearch.query')
const eeAppById = require('@ee/eeApp/eeAppById.query')
const eeAppBySearch = require('@ee/eeApp/eeAppBySearch.query')
const eeAssetById = require('@ee/eeAsset/eeAssetById.query')
const eeAssetBySearch= require('@ee/eeAsset/eeAssetBySearch.query')
const eeUserById = require('@ee/eeUser/eeUserById.query')
const eeUserBySearch = require('@ee/eeUser/eeUserBySearch.query')
const eeVulnById = require('@ee/eeVuln/eeVulnById.query')
const eeVulnBySearch = require('@ee/eeVuln/eeVulnBySearch.query')
const formById = require('@ssd/form/formById.query')
const formBySearch = require('@ssd/form/formBySearch.query')
const formQuestionById = require('@ssd/formQuestion/formQuestionById.query')
const formQuestionBySearch = require('@ssd/formQuestion/formQuestionBySearch.query')
const formResponseById = require('@ssd/formResponse/formResponseById.query')
const formResponseBySearch = require('@ssd/formResponse/formResponseBySearch.query')
const logById = require('@platform/log/logById.query')
const logBySearch = require('@platform/log/logBySearch.query')
const userById = require('@platform/user/userById.query')
const userBySearch = require('@platform/user/userBySearch.query')
const userGroupById = require('@platform/userGroup/userGroupById.query')
const userGroupBySearch = require('@platform/userGroup/userGroupBySearch.query')
const userSessionById = require('@platform/userSession/userSessionById.query')
const userSessionBySearch = require('@platform/userSession/userSessionBySearch.query')
const eeDecisionByAppId = require("@ee/eeApp/eeDecisionByAppId.query");
const eeVulnCountBySearch = require('@ee/eeVuln/eeVulnCountBySearch.query')
const queries = new GraphQLObjectType({
  name: 'queries',
  fields: {
    cronJobById: cronJobById,
    cronJobBySearch: cronJobBySearch,
    eeAppById: eeAppById,
    eeAppBySearch: eeAppBySearch,
    eeAssetById: eeAssetById,
    eeAssetBySearch: eeAssetBySearch,
    eeUserById: eeUserById,
    eeUserBySearch: eeUserBySearch,
    eeVulnById: eeVulnById,
    eeVulnBySearch: eeVulnBySearch,
    formById: formById,
    formBySearch: formBySearch,
    formQuestionById: formQuestionById,
    formQuestionBySearch: formQuestionBySearch,
    formResponseById: formResponseById,
    formResponseBySearch: formResponseBySearch,
    logById: logById,
    logBySearch: logBySearch,
    userById: userById,
    userBySearch: userBySearch,
    userGroupById: userGroupById,
    userGroupBySearch: userGroupBySearch,
    userSessionById: userSessionById,
    userSessionBySearch: userSessionBySearch,
    eeDecisionByAppId: eeDecisionByAppId,
    eeVulnCountBySearch: eeVulnCountBySearch
  },
})

module.exports = queries
