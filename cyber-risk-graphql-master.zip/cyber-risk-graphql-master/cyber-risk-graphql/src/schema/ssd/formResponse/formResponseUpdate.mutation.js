const formResponseType = require('@ssd/formResponse/formResponse.type').formResponseType
const formResponseUpdateInputType = require('@ssd/formResponse/formResponse.type')
  .formResponseUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formResponseUpdate = {
  type: formResponseType,
  description: 'add new formResponse',
  args: {
    formResponse: {type: formResponseUpdateInputType},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ssd-form-response',
      args.formResponse
    )
    return response
  },
}

module.exports = formResponseUpdate
