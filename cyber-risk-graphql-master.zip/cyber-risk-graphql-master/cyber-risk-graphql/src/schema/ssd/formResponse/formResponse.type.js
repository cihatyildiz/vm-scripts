const GraphQLObjectType = require('graphql').GraphQLObjectType
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType
const GraphQLList = require('graphql').GraphQLList
const GraphQlBigInt = require('graphql-bigint')
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLString = require('graphql').GraphQLString
const userType = require('@platform/user/user.type')
  .userType
const mongodb = require('@libs/db/mongodb').mongodb

const responseType = new GraphQLObjectType({
  name: 'responseType',
  fields: {
    questionId: {type: GraphQLString},
    answer: {type: GraphQLString}
  },
})

const responseInputType = new GraphQLInputObjectType({
  name: 'responseInputType',
  fields: {
    questionId: {type: GraphQLString},
    answer: {type: GraphQLString},
  },
})

const formResponseType = new GraphQLObjectType({
  name: 'formResponseType',
  fields: {
    id: {type: GraphQLString},
    formId: {type: GraphQLString},
    response: {type: GraphQLList(responseType)},
    createdBy: {type: GraphQLString},
    updatedBy: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  },
})

const formResponseInputType = new GraphQLInputObjectType({
  name: 'formResponseInputType',
  fields: {
    formId: {type: GraphQLString},
    response: {type: GraphQLList(responseInputType)},
    createdBy: {type:GraphQLString},
    updatedBy: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
})

const formResponseUpdateInputType = new GraphQLInputObjectType({
  name: 'formResponseUpdateInputType',
  fields: {
    formId: {type: GraphQLString},
    response: {type: GraphQLList(responseInputType)},
    createdBy: {type: GraphQLString},
    updatedBy: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
})

module.exports = {
  formResponseType: formResponseType,
  formResponseInputType: formResponseInputType,
  formResponseUpdateInputType: formResponseUpdateInputType
}
