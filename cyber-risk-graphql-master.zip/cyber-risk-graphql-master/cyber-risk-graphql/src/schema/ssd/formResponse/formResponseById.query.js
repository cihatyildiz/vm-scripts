const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const formResponseType = require('@ssd/formResponse/formResponse.type')
  .formResponseType
const mongodb = require('@libs/db/mongodb').mongodb

const formResponseById = {
  type: formResponseType,
  description: 'query by id - form Response',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ssd-form-responses',
      args.id
    )
    return response
  },
}

module.exports = formResponseById
