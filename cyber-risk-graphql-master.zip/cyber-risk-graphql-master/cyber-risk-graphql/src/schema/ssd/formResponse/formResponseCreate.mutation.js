const formResponseType = require('@ssd/formResponse/formResponse.type').formResponseType
const formResponseInputType = require('@ssd/formResponse/formResponse.type').formResponseInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formResponseCreate = {
  type: formResponseType,
  description: 'add new formResponse',
  args: {
    formResponse: {type: formResponseInputType},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ssd-form-responses',
      args.formResponse
    )
    return response
  },
}

module.exports = formResponseCreate
