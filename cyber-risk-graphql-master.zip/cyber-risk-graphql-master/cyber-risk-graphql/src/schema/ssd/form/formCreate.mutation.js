const formType = require('@ssd/form/form.type').formType
const formInputType = require('@ssd/form/form.type').formInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formCreate = {
  type: formType,
  description: 'add new form',
  args: {
    form: {type: formInputType},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ssd-forms',
      args.form
    )
    return response
  },
}

module.exports = formCreate
