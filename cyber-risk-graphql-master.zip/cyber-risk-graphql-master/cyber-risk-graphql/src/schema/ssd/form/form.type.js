const GraphQLObjectType = require('graphql').GraphQLObjectType
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType
const GraphQLList = require('graphql').GraphQLList
const GraphQlBigInt = require('graphql-bigint')
const GraphQLString = require('graphql').GraphQLString
const mongodb = require('@libs/db/mongodb').mongodb

const questionType=require('@ssd/formQuestion/formQuestion.type').formQuestionType

const formType = new GraphQLObjectType({
  name: 'formType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    description:{type:GraphQLString},
    createdBy: {type: GraphQLString},
    updatedBy:{type:GraphQLString},
    questionIds: {type: GraphQLList(GraphQLString)},
    questions: {
      type: new GraphQLList(questionType),
      resolve: async (form) => {
        if (!form.questionIds) {
          return
        }
        let items = new Array()
        await Promise.all(
          form.questionIds.map(async (id) => {
            let item = await mongodb.findByID(
              'cyber-risk-data',
              'ssd-form-questions',
              id
            )
            items.push(item)
          })
        )
        return items
      },
    },
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
})

const formInputType = new GraphQLInputObjectType({
  name: 'formInputType',
  fields: {
    name: {type: GraphQLString},
    createdBy: {type: GraphQLString},
    questionIds: {type: GraphQLList(GraphQLString)},
    description:{type:GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
})

const formUpdateInputType = new GraphQLInputObjectType({
  name: 'formUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    description: {type: GraphQLString},
    questionIds: {type: GraphQLList(GraphQLString)},
    createdBy: {type: GraphQLString},
    updatedBy:{type:GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
})



module.exports = {
  formType: formType,
  formInputType: formInputType,
  formUpdateInputType: formUpdateInputType
}
