const formType = require('@ssd/form/form.type').formType
const formUpdateInputType = require('@ssd/form/form.type').formUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formUpdate = {
  type: formType,
  description: 'Update form',
  args: {
    form: {type: formUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ssd-forms',
      args.form
    );
    return response
  }
}

module.exports = formUpdate
