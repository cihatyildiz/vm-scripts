const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const formType = require('@ssd/form/form.type').formType
const mongodb = require('@libs/db/mongodb').mongodb

const formById = {
  type: formType,
  description: 'query by id - form',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ssd-forms',
      args.id
    )
    return response
  }
}

module.exports = formById
