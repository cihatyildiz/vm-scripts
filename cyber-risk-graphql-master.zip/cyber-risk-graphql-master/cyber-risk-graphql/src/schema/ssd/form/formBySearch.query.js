const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const formType = require('@ssd/form/form.type').formType
const mongodb = require('@libs/db/mongodb').mongodb

const formBySearchResponseType = new GraphQLObjectType({
  name: 'formBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(formType)},
  },
})

const formBySearch = {
  type: formBySearchResponseType,
  description: 'query by search - form',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt},
  },
  resolve: async function (root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      'ssd-forms',
      args.query,
      args.limit,
      args.skip
    )
    return response
  },
}

module.exports = formBySearch
