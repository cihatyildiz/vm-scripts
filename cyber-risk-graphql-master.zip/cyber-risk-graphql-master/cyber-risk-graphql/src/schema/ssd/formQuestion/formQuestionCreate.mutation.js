const formQuestionType = require('@ssd/formQuestion/formQuestion.type').formQuestionType
const formQuestionInputType = require('@ssd/formQuestion/formQuestion.type').formQuestionInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formQuestionCreate = {
  type: formQuestionType,
  description: 'add new form question',
  args: {
    formQuestion: {type: formQuestionInputType},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ssd-form-questions',
      args.formQuestion
    )
    return response
  },
}

module.exports = formQuestionCreate
