const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const formQuestionType = require('@ssd/formQuestion/formQuestion.type').formQuestionType
const mongodb = require('@libs/db/mongodb').mongodb

const formQuestionBySearchResponseType = new GraphQLObjectType({
  name: 'formQuestionBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(formQuestionType)},
  },
})

const formQuestionBySearch = {
  type: formQuestionBySearchResponseType,
  description: 'query by search - form question',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt},
  },
  resolve: async function (root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      'ssd-form-questions',
      args.query,
      args.limit,
      args.skip
    )
    return response
  },
}

module.exports = formQuestionBySearch
