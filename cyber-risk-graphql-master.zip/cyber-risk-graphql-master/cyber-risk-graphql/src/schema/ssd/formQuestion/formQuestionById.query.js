const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const formQuestionType = require('@ssd/formQuestion/formQuestion.type').formQuestionType
const mongodb = require('@libs/db/mongodb').mongodb

const formQuestionById = {
  type: formQuestionType,
  description: 'query by id - formQuestion',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ssd-form-questions',
      args.id
    )
    return response
  },
}

module.exports = formQuestionById
