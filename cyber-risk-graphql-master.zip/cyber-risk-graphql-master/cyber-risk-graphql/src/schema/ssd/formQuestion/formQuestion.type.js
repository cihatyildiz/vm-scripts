const GraphQLObjectType = require('graphql').GraphQLObjectType
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType
const GraphQLList = require('graphql').GraphQLList
const GraphQlBigInt = require('graphql-bigint')
const GraphQLString = require('graphql').GraphQLString
const mongodb = require('@libs/db/mongodb').mongodb
const GraphQLJSON = require('graphql-type-json').GraphQLJSON

const formQuestionType = new GraphQLObjectType({
  name: 'formQuestionType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    helpText:{type:GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
})

const formQuestionInputType = new GraphQLInputObjectType({
  name: 'formQuestionInputType',
  fields: {
    name: {type: GraphQLString},
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    helpText: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
})

const formQuestionUpdateInputType = new GraphQLInputObjectType({
  name: 'formQuestionUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    helpText: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
})

module.exports = {
  formQuestionType: formQuestionType,
  formQuestionInputType: formQuestionInputType,
  formQuestionUpdateInputType: formQuestionUpdateInputType
}
