const formQuestionType = require('@ssd/formQuestion/formQuestion.type').formQuestionType
const formQuestionUpdateInputType = require('@ssd/formQuestion/formQuestion.type').formQuestionUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const formQuestionUpdate = {
  type: formQuestionType,
  description: 'Update formQuestion',
  args: {
    formQuestion: {type: formQuestionUpdateInputType},
  },
  resolve: async function (root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ssd-form-questions',
      args.formQuestion
    )
    return response
  },
}

module.exports = formQuestionUpdate
