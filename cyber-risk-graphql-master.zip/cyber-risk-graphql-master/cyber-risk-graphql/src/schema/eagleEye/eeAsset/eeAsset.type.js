const GraphQLObjectType = require("graphql").GraphQLObjectType;
const GraphQLInputObjectType = require("graphql").GraphQLInputObjectType;
const GraphQLString = require("graphql").GraphQLString;
const GraphQlBigInt = require('graphql-bigint')


const eeAssetType = new GraphQLObjectType({
  name: "eeAssetType",
  fields: {
    id: {type: GraphQLString},
    name: {type:GraphQLString},
    ipAddress: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


const eeAssetInputType = new GraphQLInputObjectType({
  name: "eeAssetInputType",
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    ipAddress: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


const eeAssetUpdateInputType = new GraphQLInputObjectType({
  name: "eeAssetUpdateInputType",
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    ipAddress: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


module.exports = {
  eeAssetType: eeAssetType,
  eeAssetInputType: eeAssetInputType,
  eeAssetUpdateInputType: eeAssetUpdateInputType
}
