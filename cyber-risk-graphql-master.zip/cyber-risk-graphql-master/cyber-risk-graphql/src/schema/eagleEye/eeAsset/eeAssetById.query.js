const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const eeAssetType = require('@ee/eeAsset/eeAsset.type').eeAssetType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAssetById =  {
  type: eeAssetType,
  description: 'query by id - EEAsset',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ee-assets',
      args.id
    );
    return response
  }
}

module.exports = eeAssetById
