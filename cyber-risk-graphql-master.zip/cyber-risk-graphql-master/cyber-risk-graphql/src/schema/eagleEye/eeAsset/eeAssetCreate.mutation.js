const eeAssetType = require('@ee/eeAsset/eeAsset.type').eeAssetType
const eeAssetInputType = require('@ee/eeAsset/eeAsset.type').eeAssetInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAssetCreate =  {
  type: eeAssetType,
  description: 'add new eeAsset',
  args: {
    eeAsset: {type: eeAssetInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ee-assets',
      args.eeAsset
    );
    return response
  }
}

module.exports = eeAssetCreate
