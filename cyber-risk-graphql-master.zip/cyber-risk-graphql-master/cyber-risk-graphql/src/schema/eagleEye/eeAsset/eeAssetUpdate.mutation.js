const eeAssetType = require('@ee/eeAsset/eeAsset.type').eeAssetType
const eeAssetUpdateInputType = require('@ee/eeAsset/eeAsset.type').eeAssetUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAssetUpdate = {
  type: eeAssetType,
  description: 'Update eeAsset',
  args: {
    eeAsset: {type: eeAssetUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ee-assets',
      args.eeAsset
    );
    return response
  }
}

module.exports = eeAssetUpdate
