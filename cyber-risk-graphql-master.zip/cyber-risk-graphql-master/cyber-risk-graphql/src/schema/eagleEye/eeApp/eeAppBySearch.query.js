const GraphQLList = require("graphql").GraphQLList
const GraphQLInt = require("graphql").GraphQLInt
const GraphQLJSON = require("graphql-type-json").GraphQLJSON
const GraphQLObjectType = require("graphql").GraphQLObjectType
const eeAppType = require("@ee/eeApp/eeApp.type").eeAppType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAppBySearchResponseType = new GraphQLObjectType({
  name: 'eeAppBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(eeAppType)}
  }
})


const eeAppBySearch =  {
  type: eeAppBySearchResponseType,
  description: 'query by search - eeApp',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      "ee-apps",
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = eeAppBySearch
