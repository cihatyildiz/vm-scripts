const eeAppType = require("@ee/eeApp/eeApp.type").eeAppType
const eeAppInputType = require("@ee/eeApp/eeApp.type").eeAppInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAppCreate = {
  type: eeAppType,
  description: 'add new eeApp',
  args: {
    eeApp: {type: eeAppInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ee-apps',
      args.eeApp
    );
    return response
  }
}

module.exports = eeAppCreate
