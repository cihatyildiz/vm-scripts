const eeAppType = require("@ee/eeApp/eeApp.type").eeAppType
const eeAppUpdateInputType = require("@ee/eeApp/eeApp.type").eeAppUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeAppUpdate = {
  type: eeAppType,
  description: 'add new eeApp',
  args: {
    eeApp: {type: eeAppUpdateInputType }
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ee-apps',
      args.eeApp
    );
    return response
  }
}

module.exports = eeAppUpdate
