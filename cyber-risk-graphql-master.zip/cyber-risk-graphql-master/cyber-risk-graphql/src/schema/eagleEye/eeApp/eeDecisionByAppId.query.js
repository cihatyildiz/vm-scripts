const GraphQLList = require("graphql").GraphQLList;
const GraphQLInt = require("graphql").GraphQLInt;
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const GraphQLObjectType = require("graphql").GraphQLObjectType;
const GraphQLString = require("graphql").GraphQLString;
const eeAppType = require("@ee/eeApp/eeApp.type").eeAppType;
const mongodb = require("@libs/db/mongodb").mongodb;
const GraphQLNonNull = require("graphql").GraphQLNonNull;

const eeDecisionResponseType = new GraphQLObjectType({
  name: "eeDecisionResponseType",
  fields: {
    appId: {type: GraphQLString},
    decision: {type: GraphQLString},
    reason: {type: GraphQLString},
  },
});

const eeDecisionByAppId = {
  type: eeDecisionResponseType,
  description: "query by search - eeApp",
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)},
  },
  resolve: async function (root, args, context, info) {
    let appId = args.id;
    let decision = "DENY";
    let response = "hello";
    let y = null;
    let x = await mongodb
      .findByID(process.env.ORG_DB_NAME, "ee-apps", args.id)
      .then(async (app) => {
        if (app) {
          const query = {
            appId: app.id,
            severity: {'$in': ['high', 'critical']}
          };
          if (!args.limit) {
            args.limit = 10;
          }
          if (!args.skip) {
            args.skip = 0;
          }

          await mongodb
            .search("cyber-risk-data", "ee-vulns", query, args.limit, args.skip)
            .then((response) => {
              if (response) {
                if (response.count > 0) {
                  const res = {
                    appId: args.id,
                    decision: "DENY",
                    reason: "one or more critical vulns exists",
                  };
                  y = res;
                } else {
                  const res = {
                    appId: args.id,
                    decision: "ALLOW",
                    reason: "",
                  };
                  y = res;
                }
                const log = {
                  type: 'ee-app-decision',
                  data: {
                    appId: app.id,
                    appName: app.displayName,
                    decision: y.decision,
                    vuln:response.count
                  }
                }
                mongodb.addOne(
                   process.env.ORG_DB_NAME,
                  'logs',
                  log
                );
              }
            })
            .catch((err) => {
              console.log(err);
            });
        } else {
          return;
        }
      })
      .catch((err) => {
        console.log(err);
      });

    return y;
  },
};
module.exports = eeDecisionByAppId;
