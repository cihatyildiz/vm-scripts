const GraphQLObjectType = require("graphql").GraphQLObjectType;
const GraphQLInputObjectType = require("graphql").GraphQLInputObjectType;
const GraphQLList = require("graphql").GraphQLList;
const GraphQlBigInt = require('graphql-bigint');
const GraphQLInt = require("graphql").GraphQLInt;
const GraphQLString = require("graphql").GraphQLString;
const userGroupType = require('@platform/userGroup/userGroup.type').userGroupType
const mongodb = require('@libs/db/mongodb').mongodb

const fortifyType = new GraphQLObjectType({
  name: "fortifyType",
  fields: {
    gitUrl: {type: GraphQLString},
    projectName: {type: GraphQLString},
    projectId: {type:GraphQLInt}
  }
});


const fortifyInputType = new GraphQLInputObjectType({
  name: "fortifyInputType",
  fields: {
    gitUrl: {type: GraphQLString},
    projectName: {type: GraphQLString},
    projectId: {type: GraphQLInt},
  }
});


const xrayType = new GraphQLObjectType({
  name: "xrayType",
  fields: {
    xrayWatchName: {type: GraphQLString},
    latestVersion: {type: GraphQLString},
    versions: {type: GraphQLList(GraphQLString)},
  },
} );


const xrayInputType = new GraphQLInputObjectType({
  name: "xrayInputType",
  fields: {
    xrayWatchName: {type: GraphQLString},
    latestVersion: {type: GraphQLString},
    versions: {type: GraphQLList(GraphQLString)},
  },
});


const eeAppConfigType = new GraphQLObjectType({
  name: "eeAppConfigType",
  fields: {
    contrastAppId: {type: GraphQLString},
    fortify: {type: fortifyType},
    xray: {type: xrayType},
    artifactoryPath: {type: GraphQLString},
    cronjobIds: {type: GraphQLList(GraphQLString)},
  },
});


const eeAppConfigInputType = new GraphQLInputObjectType({
  name: "eeAppConfigInputType",
  fields: {
    contrastAppId: {type: GraphQLString},
    fortify:{type:fortifyInputType},
    xray:{type:xrayInputType},
    artifactoryPath:{type:GraphQLString},
    cronjobIds: {type: GraphQLList(GraphQLString)}
  }
})


const eeAppType = new GraphQLObjectType({
  name: "eeAppType",
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    displayName:{type:GraphQLString},
    config: {type: eeAppConfigType},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    userGroups: {
      type: new GraphQLList(userGroupType),
      resolve: async (eeApp) => {
        if (!eeApp.userGroupIds) {
          return
        }
        let items = new Array()
        await Promise.all(eeApp.userGroupIds.map(
          async (id) => {
            let item = await mongodb.findByID(
              'cyber-risk-data',
              'user-groups',
              id
            )
            items.push(item)
          }
        ))
        return items
      }},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const eeAppInputType = new GraphQLInputObjectType({
  name: "eeAppInputType",
  fields: {
    name: {type: GraphQLString},
    displayName:{type:GraphQLString},
    config: {type: eeAppConfigInputType},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


const eeAppUpdateInputType = new GraphQLInputObjectType({
  name: "eeAppUpdateInputType",
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    displayName:{type:GraphQLString},
    config: {type: eeAppConfigInputType},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});

const eeDecisionType = new GraphQLObjectType({
  name: "eeDecisionType",
  fields: {
    appId: {type: GraphQLString},
    Decison: {type: GraphQLString},
    reason: {type: GraphQLString}
  }
});

module.exports = {
  eeAppType: eeAppType,
  eeAppInputType: eeAppInputType,
  eeAppUpdateInputType: eeAppUpdateInputType,
  eeDecisionType:eeDecisionType
}
