const eeVulnType = require('@ee/eeVuln/eeVuln.type').eeVulnType
const eeVulnInputType = require('@ee/eeVuln/eeVuln.type').eeVulnInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeVulnCreate =  {
  type: eeVulnType,
  description: 'add new eeVuln',
  args: {
    eeVuln: {type: eeVulnInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ee-vulns',
      args.eeVuln
    );
    return response
  }
}

module.exports = eeVulnCreate
