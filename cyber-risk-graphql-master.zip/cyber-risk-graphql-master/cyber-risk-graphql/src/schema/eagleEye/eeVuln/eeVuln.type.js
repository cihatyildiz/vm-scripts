const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQLString = require('graphql').GraphQLString;
const GraphQlBigInt = require('graphql-bigint')
const eeAppType = require('@ee/eeApp/eeApp.type').eeAppType
const mongodb = require('@libs/db/mongodb').mongodb
const eeAssetType=require('@ee/eeAsset/eeAsset.type').eeAssetType

const eeVulnDetailsType = new GraphQLObjectType({
  name: 'eeVulnDetailsType',
  fields: {
    info: {type: GraphQLString},
    recommendations: {type: GraphQLString},
    references: {type: GraphQLString}
  }
})


const eeVulnDetailsInputType = new GraphQLInputObjectType({
  name: 'eeVulnDetailsInputType',
  fields: {
    info: {type: GraphQLString},
    recommendations: {type: GraphQLString},
    references: {type: GraphQLString}
  }
})


const eeVulnType = new GraphQLObjectType({
  name: 'eeVulnType',
  fields: {
    id: {type: GraphQLString},
    title: {type: GraphQLString},
    severity: {type: GraphQLString},
    status: {type: GraphQLString},
    appId: {type: GraphQLString},
    app: {
      type: eeAppType,
      resolve: async ( eeVuln ) => {
        if ( !eeVuln.appId ) {
          return
        }
        let theme = await mongodb.findByID(
          process.env.ORG_DB_NAME,
          'ee-apps',
          eeVuln.appId
        )
        return theme
      }
    },
    assetId: { type: GraphQLString },
    asset: {
      type: eeAssetType,
      resolve: async ( eeVuln ) => {
        if ( !eeVuln.assetId ) {
          return
        }
        let theme = await mongodb.findByID(
          process.env.ORG_DB_NAME,
          'ee-assets',
          eeVuln.assetId
        )
        return theme
      }
    },
    jiraTicketKey:{type:GraphQLString},
    details: {type: eeVulnDetailsType},
    srcTool: {type: GraphQLString},
    srcToolId: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const eeVulnInputType = new GraphQLInputObjectType({
  name: 'eeVulnInputType',
  fields: {
    title: {type: GraphQLString},
    severity: {type: GraphQLString},
    status: {type: GraphQLString},
    appId:  {type: GraphQLString },
    assetId:{type:GraphQLString},
    details: {type: eeVulnDetailsInputType},
    jiraTicketKey:{type:GraphQLString},
    srcTool: {type: GraphQLString},
    srcToolId: {type: GraphQLString},
    srcLocation: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const eeVulnUpdateInputType = new GraphQLInputObjectType({
  name: 'eeVulnUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    title: {type: GraphQLString},
    severity: {type: GraphQLString},
    status: {type: GraphQLString},
    appId: {type: GraphQLString},
    assetId:{type:GraphQLString},
    details: {type: eeVulnDetailsInputType},
    jiraTicketKey:{type:GraphQLString},
    srcTool: {type: GraphQLString},
    srcToolId: {type: GraphQLString},
    srcLocation: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


module.exports = {
  eeVulnType: eeVulnType,
  eeVulnInputType: eeVulnInputType,
  eeVulnUpdateInputType: eeVulnUpdateInputType
}
