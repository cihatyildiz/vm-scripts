const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const eeVulnType = require('@ee/eeVuln/eeVuln.type').eeVulnType
const mongodb = require('@libs/db/mongodb').mongodb


const eeVulnBySearchResponseType = new GraphQLObjectType({
  name: 'eeVulnBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(eeVulnType)}
  }
})


const eeVulnBySearch =  {
  type: eeVulnBySearchResponseType,
  description: 'query by search - eeVuln',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response  = await mongodb.search(
      process.env.ORG_DB_NAME,
      'ee-vulns',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = eeVulnBySearch
