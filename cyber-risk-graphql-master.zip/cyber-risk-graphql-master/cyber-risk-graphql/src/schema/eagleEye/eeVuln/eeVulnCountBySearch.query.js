const {GraphQLString} = require('graphql')

const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const eeVulnType = require('@ee/eeVuln/eeVuln.type').eeVulnType
const mongodb = require('@libs/db/mongodb').mongodb

const eeVulnCountType = new GraphQLObjectType({
  name: 'eeVulnCountType',
  fields: {
    info: {type:  GraphQLInt},
    low: {type: GraphQLInt},
    medium: {type: GraphQLInt},
    high: {type: GraphQLInt},
    critical: {type: GraphQLInt}
  }
})


const eeVulnCountBySearch = {
  type: eeVulnCountType,
  description: 'query by search - eeVuln',
  args: {
    query: {type: GraphQLJSON},
    field:{type:GraphQLString}
  },
  resolve: async function (root, args, context, info) {
    if (!args.field) {
      args.field = '$severity'
    }
    const response = await mongodb.aggregateCountByField(
      process.env.ORG_DB_NAME,
      'ee-vulns',
      args.query,
      args.field
    )
    console.log('response', response)
    let x={}
    response.map(object=> {
      x[object['_id']] = object['count']
    })
    return x
  }
}

module.exports = eeVulnCountBySearch
