const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const eeVulnType = require('@ee/eeVuln/eeVuln.type').eeVulnType
const mongodb = require('@libs/db/mongodb').mongodb


const eeVulnByID =  {
  type: eeVulnType,
  description: 'query by id - eeVuln',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ee-vulns',
      args.id
    );
    return response
  }
}

module.exports = eeVulnByID
