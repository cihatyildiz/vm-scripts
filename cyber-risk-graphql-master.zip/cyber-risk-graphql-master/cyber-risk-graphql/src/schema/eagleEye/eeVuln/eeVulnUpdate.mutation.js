const eeVulnType = require('@ee/eeVuln/eeVuln.type').eeVulnType
const eeVulnUpdateInputType = require('@ee/eeVuln/eeVuln.type').eeVulnUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeVulnUpdate =  {
  type: eeVulnType,
  description: 'add new eeVuln',
  args: {
    eeVuln: {type: eeVulnUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ee-vulns',
      args.eeVuln
    );
    return response
  }
}

module.exports = eeVulnUpdate
