const eeUserType = require('@ee/eeUser/eeUser.type').eeUserType
const eeUserUpdateInputType = require('@ee/eeUser/eeUser.type').eeUserUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const eeUserUpdate = {
  type: eeUserType,
  description: 'add new eeUser',
  args: {
    eeUser: {type: eeUserUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'ee-users',
      args.eeUser
    );
    return response
  }
}

module.exports = eeUserUpdate
