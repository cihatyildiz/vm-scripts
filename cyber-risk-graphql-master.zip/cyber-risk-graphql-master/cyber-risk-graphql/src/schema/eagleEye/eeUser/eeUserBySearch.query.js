const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const eeUserType = require('@ee/eeUser/eeUser.type').eeUserType
const mongodb = require('@libs/db/mongodb').mongodb

const eeUserBySearchResponseType = new GraphQLObjectType({
  name: 'eeUserBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(eeUserType)}
  }
})


const eeUserBySearch =  {
  type: eeUserBySearchResponseType,
  description: 'query by search - eeUser',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      'ee-users',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = eeUserBySearch
