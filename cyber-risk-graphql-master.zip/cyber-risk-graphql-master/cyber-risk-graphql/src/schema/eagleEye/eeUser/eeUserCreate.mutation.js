const eeUserType = require('@ee/eeUser/eeUser.type').eeUserType
const eeUserInputType = require('@ee/eeUser/eeUser.type').eeUserInputType
const mongodb = require('@libs/db/mongodb').mongodb


const eeUserCreate =  {
  type: eeUserType,
  description: 'add new eeUser',
  args: {
    eeUser: {type: eeUserInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'ee-users',
      args.eeUser
    );
    return response
  }
}

module.exports = eeUserCreate
