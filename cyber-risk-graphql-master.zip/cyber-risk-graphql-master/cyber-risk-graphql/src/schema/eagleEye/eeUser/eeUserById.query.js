const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const eeUserType = require('@ee/eeUser/eeUser.type').eeUserType
const mongodb = require('@libs/db/mongodb').mongodb


const eeUserByID =  {
  type: eeUserType,
  description: 'query by id - eeUser',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'ee-users',
      args.id
    );
    return response
  }
}

module.exports = eeUserByID
