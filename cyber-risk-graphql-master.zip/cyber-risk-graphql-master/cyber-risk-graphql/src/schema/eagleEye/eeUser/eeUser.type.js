const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQlBigInt = require('graphql-bigint')
const GraphQLList = require('graphql').GraphQLList
const GraphQLString = require('graphql').GraphQLString;
const eeAppType = require('@ee/eeApp/eeApp.type').eeAppType
const userType = require('@platform/user/user.type').userType
const mongodb = require('@libs/db/mongodb').mongodb


const eeUserType = new GraphQLObjectType({
  name: 'eeUserType',
  fields: {
    id: {type: GraphQLString},
    userId: {type: GraphQLString},
    user: {
      type: userType,
      resolve: async (eeUser) => {
        let user = await mongodb.findByID(
          process.env.ORG_DB_NAME,
          'users',
          eeUser.userId
        );
        return user
      }
    },
    appIds: {type: GraphQLList(GraphQLString)},
    apps: {
      type: new GraphQLList(eeAppType),
      resolve: async (eeUser) => {
        let assets = new Array()
        await Promise.all(eeUser.appIds.map(
          async (id) => {
            let asset = await mongodb.findByID(
              process.env.ORG_DB_NAME,
              'ee-apps',
              id
            );
            assets.push(asset)
          }
        ))
        return assets
      }
    },
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const eeUserInputType = new GraphQLInputObjectType({
  name: 'eeUserInputType',
  fields: {
    userId: {type: GraphQLString},
    appIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const eeUserUpdateInputType = new GraphQLInputObjectType({
  name: 'eeUserUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    userId: {type: GraphQLString},
    appIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


module.exports = {
  eeUserType: eeUserType,
  eeUserInputType: eeUserInputType,
  eeUserUpdateInputType: eeUserUpdateInputType
}
