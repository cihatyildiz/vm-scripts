const GraphQLObjectType = require("graphql").GraphQLObjectType;
const GraphQLInputObjectType = require("graphql").GraphQLInputObjectType;
const GraphQlBigInt = require("graphql-bigint");
const GraphQLString = require("graphql").GraphQLString;

const eeJiraTicketType = new GraphQLObjectType({
  name: "eeJiraTicketType",
  fields: {
    id: {type: GraphQLString},
    key:{type:GraphQLString}
  },
});

const eeJiraTicketInputType = new GraphQLInputObjectType({
  name: "eeJiraTicketInputType",
  fields: {
    projectKey: {type: GraphQLString},
    summary:{type:GraphQLString},
    issueType: {type: GraphQLString},
    priority:{type:GraphQLString},
    description: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
});

const eeJiraTicketUpdateInputType = new GraphQLInputObjectType({
  name: 'eeJiraTicketUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    projectKey: {type: GraphQLString},
    summary: {type: GraphQLString},
    issueType: {type: GraphQLString},
    priority: {type: GraphQLString},
    description: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  },
})

module.exports = {
  eeJiraTicketType: eeJiraTicketType,
  eeJiraTicketInputType: eeJiraTicketInputType,
  eeJiraTicketUpdateInputType: eeJiraTicketUpdateInputType
};
