const axios = require("axios");
const fetch=require("node-fetch");
var request = require("request").defaults({rejectUnauthorized: false});
const https = require('https'); //Add This
const {response} = require('express');
const {GraphQLObjectType} = require('graphql');
const eeJiraTicketType = require("@ee/eeJiraTicket/eeJiraTicket.type").eeJiraTicketType;
const eeJiraTicketInputType = require("@ee/eeJiraTicket/eeJiraTicket.type")
  .eeJiraTicketInputType;
const mongodb = require("@libs/db/mongodb").mongodb;

const eeJiraTicketCreate = {
  type: eeJiraTicketType,
  description: "create a jira Ticket",
  args: {
    eeJiraTicket: {type: eeJiraTicketInputType},
  },
  resolve: async function (root, args, context, info) {
    const eeJiraTicket = args.eeJiraTicket;
    const httpsAgent = new https.Agent({
      rejectUnauthorized: false,
    });
    var myHeaders = {
      'Content-Type': 'application/json',
      Authorization: 'Basic RU5UX1NWQ19KSVJBLUJPVDpVZ2x5YW5nbGUyOA==',
      'Content-Type': 'application/json',
    }
    var raw = JSON.stringify({
      fields: {
        project: {key: eeJiraTicket.projectKey},
        issuetype: {name: eeJiraTicket.issueType},
        summary: eeJiraTicket.summary,
        description: eeJiraTicket.description,
        priority:{name:eeJiraTicket.priority}
      },
    });
    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
      agent: httpsAgent,
    };
    let project ={}
    return await fetch("https://atlassian/jira/rest/api/2/issue", requestOptions)
      .then((response) => response.json())
      .then((result) => {
        project.id = result.id
        project.key=result.key
      return project
     }
   )
   .catch((error) => console.log("error", error));
  }
  }


module.exports = eeJiraTicketCreate;

