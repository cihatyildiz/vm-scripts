// const GraphQLNonNull = require("graphql").GraphQLNonNull;
// const GraphQLString = require("graphql").GraphQLString;
// const eeJiraTicketType = require("@ee/eeApp/eeApp.type").eeAppType;
// const mongodb = require("@libs/db/mongodb").mongodb;

// const eeJiraTicketById = {
//   type: eeJiraTicketType,
//   description: "query by id - eeJiraTicket",
//   args: {
//     id: {type: new GraphQLNonNull(GraphQLString)},
//   },
//   resolve: async function (root, args, context, info) {
//     const response = await mongodb.findByID(
//       process.env.ORG_DB_NAME,
//       "ee-apps",
//       args.id
//     );
//     return response;
//   },
// };

// module.exports = eeJiraTicketById;
