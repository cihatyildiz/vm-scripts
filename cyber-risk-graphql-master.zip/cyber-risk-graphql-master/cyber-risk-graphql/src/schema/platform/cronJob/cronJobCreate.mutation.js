const cronJobType = require('@platform/cronJob/cronJob.type').cronJobType
const cronJobInputType = require('@platform/cronJob/cronJob.type').cronJobInputType
const mongodb = require('@libs/db/mongodb').mongodb


const cronJobCreate = {
  type: cronJobType,
  description: 'add new cronJob',
  args: {
    cronJob: {type: cronJobInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'cron-jobs',
      args.cronJob
    );
    return response
  }
}

module.exports = cronJobCreate
