const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQLString = require('graphql').GraphQLString;
const GraphQlBigInt = require('graphql-bigint')


const cronJobType = new GraphQLObjectType({
  name: 'cronJobType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    schedule: {type: GraphQLString},
    command: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const cronJobInputType = new GraphQLInputObjectType({
  name: 'cronJobInputType',
  fields: {
    name: {type: GraphQLString},
    schedule: {type: GraphQLString},
    command: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const cronJobUpdateInputType = new GraphQLInputObjectType({
  name: 'cronJobUpdateInputType',
  fields: {
    id:{type:GraphQLString},
    name: {type: GraphQLString},
    schedule: {type: GraphQLString},
    command: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


module.exports = {
  cronJobType: cronJobType,
  cronJobInputType: cronJobInputType,
  cronJobUpdateInputType: cronJobUpdateInputType
}
