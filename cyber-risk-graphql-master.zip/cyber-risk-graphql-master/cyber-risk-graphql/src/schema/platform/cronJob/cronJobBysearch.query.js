const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const cronJobType = require('@platform/cronJob/cronJob.type').cronJobType
const mongodb = require('@libs/db/mongodb').mongodb


const cronJobBySearchResponseType = new GraphQLObjectType({
  name: 'cronJobBySearchResponseType',
  fields: {
    count:  {type: GraphQLInt},
    data: {type: new GraphQLList(cronJobType)}
  }
})


const cronJobBySearch = {
  type: cronJobBySearchResponseType,
  description: 'query by search - cronJob',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      'cron-jobs',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = cronJobBySearch
