const cronJobType = require('@platform/cronJob/cronJob.type').cronJobType
const cronJobUpdateInputType = require('@platform/cronJob/cronJob.type').cronJobUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const cronJobUpdate = {
  type: cronJobType,
  description: 'update cronJob',
  args: {
    cronJob: {type: cronJobUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'cron-jobs',
      args.cronJob
    );
    return response
  }
}

module.exports = cronJobUpdate
