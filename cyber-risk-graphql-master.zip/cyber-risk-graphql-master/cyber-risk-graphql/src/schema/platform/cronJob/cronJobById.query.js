const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const cronJobType = require('@platform/cronJob/cronJob.type').cronJobType
const mongodb = require('@libs/db/mongodb').mongodb


const cronJobById = {
  type: cronJobType,
  description: 'query by id - cronJob',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'cron-jobs',
      args.id
    );
    return response
  }
}

module.exports = cronJobById
