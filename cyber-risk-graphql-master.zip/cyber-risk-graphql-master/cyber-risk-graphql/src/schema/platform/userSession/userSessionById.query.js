const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const userSessionType = require('@platform/userSession/userSession.type').userSessionType
const mongodb = require('@libs/db/mongodb').mongodb


const userSessionById = {
  type: userSessionType,
  description: 'query by id - userSession',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'user-sessions',
      args.id
    );
    return response
  }
}

module.exports = userSessionById
