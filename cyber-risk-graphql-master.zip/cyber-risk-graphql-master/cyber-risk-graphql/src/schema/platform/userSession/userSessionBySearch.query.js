const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const userSessionType = require('@platform/userSession/userSession.type').userSessionType
const mongodb = require('@libs/db/mongodb').mongodb


const userSessionBySearchResponseType = new GraphQLObjectType({
  name: 'userSessionBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(userSessionType)}
  }
})


const userSessionBySearch =  {
  type: userSessionBySearchResponseType,
  description: 'query by search - userSession',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response  = await mongodb.search(
      'cyber-risk-data',
      'user-sessions',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = userSessionBySearch
