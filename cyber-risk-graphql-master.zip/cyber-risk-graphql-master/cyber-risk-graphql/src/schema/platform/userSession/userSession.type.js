const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQLString = require('graphql').GraphQLString;
const GraphQlBigInt = require('graphql-bigint')


const userSessionType = new GraphQLObjectType({
  name: 'userSessionType',
  fields: {
    id: {type: GraphQLString},
    userId: {type: GraphQLString},
    status: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const userSessionInputType = new GraphQLInputObjectType({
  name: 'userSessionInputType',
  fields: {
    userId: {type: GraphQLString},
    status: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const userSessionUpdateInputType = new GraphQLInputObjectType({
  name: 'userSessionUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    userId: {type: GraphQLString},
    status: {type: GraphQLString},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


module.exports = {
  userSessionType: userSessionType,
  userSessionInputType: userSessionInputType,
  userSessionUpdateInputType: userSessionUpdateInputType
}
