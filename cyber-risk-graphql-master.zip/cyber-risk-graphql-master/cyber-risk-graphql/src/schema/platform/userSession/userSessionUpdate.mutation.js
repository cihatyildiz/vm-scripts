const userSessionType = require('@platform/userSession/userSession.type').userSessionType
const userSessionUpdateInputType = require('@platform/userSession/userSession.type').userSessionUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const userSessionUpdate = {
  type: userSessionType,
  description: 'add new userSession',
  args: {
    userSession: {type: userSessionUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'user-sessions',
      args.userSession
    );
    return response
  }
}

module.exports = userSessionUpdate
