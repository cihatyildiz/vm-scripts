const userSessionType = require("@platform/userSession/userSession.type").userSessionType
const userSessionInputType = require("@platform/userSession/userSession.type").userSessionInputType
const mongodb = require( '@libs/db/mongodb' ).mongodb

const userSessionCreate = {
  type: userSessionType,
  description: 'add new userSession',
  args: {
    userSession: {type: userSessionInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'user-sessions',
      args.userSession
    );
    return response
  }
}

module.exports = userSessionCreate
