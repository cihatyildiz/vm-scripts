const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const userType = require('@platform/user/user.type').userType
const mongodb = require('@libs/db/mongodb').mongodb


const userBySearchResponseType = new GraphQLObjectType({
  name: 'userBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(userType)}
  }
})


const userBySearch =  {
  type: userBySearchResponseType,
  description: 'query by search - User',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response  = await mongodb.search(
      process.env.ORG_DB_NAME,
      'users',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = userBySearch
