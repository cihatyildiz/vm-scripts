const userType = require('@platform/user/user.type').userType
const userInputType = require('@platform/user/user.type').userInputType
const mongodb = require('@libs/db/mongodb').mongodb


const userCreate = {
  type: userType,
  description: 'add new User',
  args: {
    user: {type: userInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'users',
      args.user
    );
    return response
  }
}

module.exports = userCreate
