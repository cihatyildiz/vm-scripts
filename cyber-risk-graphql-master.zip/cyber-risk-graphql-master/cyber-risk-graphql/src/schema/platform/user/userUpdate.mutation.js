const userType = require('@platform/user/user.type').userType
const userUpdateInputType = require('@platform/user/user.type').userUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb


const updateUser = {
  type: userType,
  description: 'Update User',
  args: {
    user: {type: userUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'users',
      args.user
    );
    return response
  }
}

module.exports = updateUser
