const GraphQLString = require('graphql').GraphQLString;
const ActiveDirectory = require('activedirectory');
const mongodb = require('@libs/db/mongodb').mongodb
 const userSessionType = require("@platform/userSession/userSession.type")
   .userSessionType;

const userAuthenticate = {
  type: userSessionType,
  description: "UserAuthenticate",
  args: {
    username: {type: GraphQLString},
    password: {type: GraphQLString},
  },
  resolve: async function (root, args, context, info) {
    let session = null;
    const config = {
      url: "ldap://deltads-ads-vip.deltads.ent:389",
      baseDN: "dc=deltads,dc=ent",
    };
    const ad = new ActiveDirectory(config);
    const username = args.username;
    const password = args.password;
    let isAuthenticated = null;
    let log = {
        type: 'user-sign-in',
        data: {
          username: args.username
        }
      }
    let promise = new Promise(function (resolve, reject) {
      ad.authenticate(username, password, function (err, auth) {
        if (err) {
          console.log("ERROR: " + JSON.stringify(err));
          isAuthenticated = false;
          reject(isAuthenticated);
        }
        if (auth) {
          isAuthenticated = true;
           resolve('Hello')
        } else {
          isAuthenticated = false;
          reject(isAuthenticated);
        }
      });
    });
    promise = promise.then(async function (isAuthenticated) {
      if (isAuthenticated) {
        console.log("user ad creds are fine");
        const query = {
          username: args.username,
        };
        const limit = 1;
        const skip = 0;
        let response = await mongodb.search(
          "cyber-risk-data",
          "users",
          query,
          limit,
          skip
        );
        if (response && response.count === 1) {
          userId = response.data[0].id;
          log.data.userId = userId
          log.data.username = response.data[0].username
          log.data.name = response.data[0].name
          log.data.status="SUCCESS"
          response = await mongodb.addOne("cyber-risk-data", "user-sessions", {
            userId: userId,
            status: "ACTIVE",
          });
          session = response;
        }
         await mongodb.addOne(process.env.ORG_DB_NAME,'logs',log)
        return session;
      } else {
        console.log("user creds are not good");
        log.data.status = "FAILED"
        await mongodb.addOne(process.env.ORG_DB_NAME, 'logs', log)
      }
    }).catch(err => {
       log.data.status = "FAILED"
        mongodb.addOne(process.env.ORG_DB_NAME, 'logs', log)
    });
    return promise;
  },
};

module.exports = userAuthenticate
