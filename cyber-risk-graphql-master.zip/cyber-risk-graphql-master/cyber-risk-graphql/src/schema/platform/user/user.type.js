const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQLList = require('graphql').GraphQLList
const GraphQlBigInt = require('graphql-bigint')
const GraphQLString = require('graphql').GraphQLString;


const userType = new GraphQLObjectType({
  name: 'userType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    username: {type: GraphQLString},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


const userInputType = new GraphQLInputObjectType({
  name: 'userInputType',
  fields: {
    name:{type:GraphQLString},
    username: {type: GraphQLString},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});


const userUpdateInputType = new GraphQLInputObjectType({
  name: 'userUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString },
    username: {type: GraphQLString},
    userGroupIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt}
  }
});



module.exports = {
  userType: userType,
  userInputType: userInputType,
  userUpdateInputType: userUpdateInputType,
};
