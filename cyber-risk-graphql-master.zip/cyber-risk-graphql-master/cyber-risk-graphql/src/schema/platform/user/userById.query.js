const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const userType = require('@platform/user/user.type').userType
const mongodb = require('@libs/db/mongodb').mongodb


const userById =  {
  type: userType,
  description: 'query by id - User',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'users',
      args.id
    );
    return response
  }
}

module.exports = userById
