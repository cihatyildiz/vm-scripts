const userGroupType = require('@platform/userGroup/userGroup.type').userGroupType
const userGroupInputType = require('@platform/userGroup/userGroup.type').userGroupInputType
const mongodb = require( '@libs/db/mongodb' ).mongodb


const userGroupCreate =  {
  type: userGroupType,
  description: 'add new User Group',
  args: {
    userGroup: {type: userGroupInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'user-groups',
      args.userGroup
    );
    return response
  }
}

module.exports = userGroupCreate
