const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQLList = require('graphql').GraphQLList
const GraphQLString = require('graphql').GraphQLString;
const GraphQlBigInt = require('graphql-bigint')
const userType = require('@platform/user/user.type').userType
const mongodb = require('@libs/db/mongodb').mongodb


const userGroupType = new GraphQLObjectType({
  name: 'userGroupType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    desc: {type: GraphQLString},
    userIds: {type: GraphQLList(GraphQLString)},
    users: {
      type: new GraphQLList(userType),
        resolve: async (userGroup) => {
         if (!userGroup.userIds) {
          return
        }
        let items = new Array()
         await Promise.all(userGroup.userIds.map(
          async (id) => {
            let item = await mongodb.findByID(
              'cyber-risk-data',
              'users',
              id
            )
            items.push(item)
         }
        ) )
      return items
      }
    },
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const userGroupInputType = new GraphQLInputObjectType({
  name: 'userGroupInputType',
  fields: {
    name: {type: GraphQLString},
    desc: {type: GraphQLString},
    userIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


const userGroupUpdateInputType = new GraphQLInputObjectType({
  name: 'userGroupUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    name: {type: GraphQLString},
    desc: {type: GraphQLString},
    userIds: {type: GraphQLList(GraphQLString)},
    tsCreate: {type: GraphQlBigInt},
    tsUpdate: {type: GraphQlBigInt},
  }
});


module.exports = {
  userGroupType: userGroupType,
  userGroupInputType: userGroupInputType,
  userGroupUpdateInputType: userGroupUpdateInputType
}
