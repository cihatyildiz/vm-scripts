const GraphQLList = require('graphql').GraphQLList
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLObjectType = require('graphql').GraphQLObjectType
const userGroupType = require('@platform/userGroup/userGroup.type').userGroupType
const mongodb = require('@libs/db/mongodb').mongodb


const userGroupBySearchResponseType = new GraphQLObjectType({
  name: 'userGroupBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(userGroupType)}
  }
})


const userGroupBySearch =  {
  type: userGroupBySearchResponseType,
  description: 'query by search - userGroup',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response  = await mongodb.search(
      process.env.ORG_DB_NAME,
      'user-groups',
      args.query,
      args.limit,
      args.skip
    );
    return response
  }
}

module.exports = userGroupBySearch
