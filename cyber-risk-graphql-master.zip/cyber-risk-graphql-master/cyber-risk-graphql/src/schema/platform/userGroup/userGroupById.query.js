const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const userGroupType = require('@platform/userGroup/userGroup.type').userGroupType
const mongodb = require('@libs/db/mongodb').mongodb


const userGroupById =  {
  type: userGroupType,
  description: 'query by id - userGroup',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'user-groups',
      args.id
    );
    return response
  }
}

module.exports = userGroupById
