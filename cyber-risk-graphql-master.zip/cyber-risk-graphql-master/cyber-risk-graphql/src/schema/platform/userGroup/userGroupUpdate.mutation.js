const userGroupType = require('@platform/userGroup/userGroup.type').userGroupType
const userGroupUpdateInputType = require('@platform/userGroup/userGroup.type').userGroupUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const userGroupUpdate = {
  type: userGroupType,
  description: 'Update UserGroup',
  args: {
    userGroup: {type: userGroupUpdateInputType}
  },
  resolve: async function(root, args, context, info) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'user-groups',
      args.userGroup
    );
    return response
  }
}

module.exports = userGroupUpdate
