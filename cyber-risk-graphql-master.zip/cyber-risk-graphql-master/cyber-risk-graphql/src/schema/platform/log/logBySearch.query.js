const GraphQLList = require( 'graphql' ).GraphQLList
const GraphQLObjectType = require( 'graphql' ).GraphQLObjectType
const GraphQLInt = require('graphql').GraphQLInt
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const logType = require('@platform/log/log.type').logType
const mongodb = require('@libs/db/mongodb').mongodb


const logBySearchResponseType = new GraphQLObjectType({
  name: 'logBySearchResponseType',
  fields: {
    count: {type: GraphQLInt},
    data: {type: new GraphQLList(logType)}
  }
})


const logBySearch =  {
  type: logBySearchResponseType,
  description: 'query by search - log',
  args: {
    query: {type: GraphQLJSON},
    limit: {type: GraphQLInt},
    skip: {type: GraphQLInt},
    sort: {type: GraphQLJSON}
  },
  resolve: async function(root, args, context, info) {
    if (!args.limit) {
      args.limit = 0
    }
    if (!args.skip) {
      args.skip = 0
    }
    const response = await mongodb.search(
      process.env.ORG_DB_NAME,
      'logs',
      args.query,
      args.limit,
      args.skip,
      args.sort
    );
    return response
  }
}

module.exports = logBySearch
