const logType = require( '@platform/log/log.type' ).logType
const logUpdateInputType = require( '@platform/log/log.type' ).logUpdateInputType
const mongodb = require('@libs/db/mongodb').mongodb

const logUpdate = {
  type: logType,
  description: 'update log',
  args: {
    log: {type: logUpdateInputType}
  },
  resolve: async function ( root, args, context, info ) {
    const response = await mongodb.updateOne(
      process.env.ORG_DB_NAME,
      'logs',
      args.log
    );
    return response
  }
}

module.exports = logUpdate
