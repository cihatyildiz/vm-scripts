const logType = require('@platform/log/log.type').logType
const logInputType = require('@platform/log/log.type').logInputType
const mongodb = require('@libs/db/mongodb').mongodb


const logCreate =  {
  type: logType,
  description: 'add new log',
  args: {
    log: {type: logInputType}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.addOne(
      process.env.ORG_DB_NAME,
      'logs',
      args.log
    );
    return response
  }
}

module.exports = logCreate
