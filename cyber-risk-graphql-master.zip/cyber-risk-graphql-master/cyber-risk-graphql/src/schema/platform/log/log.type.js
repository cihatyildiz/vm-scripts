const GraphQLObjectType = require('graphql').GraphQLObjectType;
const GraphQLInputObjectType = require('graphql').GraphQLInputObjectType;
const GraphQlBigInt = require('graphql-bigint')
const GraphQLJSON = require('graphql-type-json').GraphQLJSON
const GraphQLString = require('graphql').GraphQLString;


const logType = new GraphQLObjectType({
  name: 'logType',
  fields: {
    id: {type: GraphQLString},
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    tsCreate: { type: GraphQlBigInt},
    tsUpdate: { type: GraphQlBigInt},
  }
});


const logInputType = new GraphQLInputObjectType({
  name: 'logInputType',
  fields: {
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    tsCreate: { type: GraphQlBigInt},
    tsUpdate: { type: GraphQlBigInt},
  }
});


const logUpdateInputType = new GraphQLInputObjectType({
  name: 'logUpdateInputType',
  fields: {
    id: {type: GraphQLString},
    type: {type: GraphQLString},
    data: {type: GraphQLJSON},
    tsCreate: { type: GraphQlBigInt},
    tsUpdate: { type: GraphQlBigInt},
  }
});


module.exports = {
  logType: logType,
  logInputType: logInputType,
  logUpdateInputType: logUpdateInputType
}
