const GraphQLNonNull = require('graphql').GraphQLNonNull
const GraphQLString = require('graphql').GraphQLString
const logType = require('@platform/log/log.type').logType
const mongodb = require('@libs/db/mongodb').mongodb


const logById =  {
  type: logType,
  description: 'query by id - log',
  args: {
    id: {type: new GraphQLNonNull(GraphQLString)}
  },
  resolve: async function(root, args, context, info) {
    const response  = await mongodb.findByID(
      process.env.ORG_DB_NAME,
      'logs',
      args.id
    );
    return response
  }
}

module.exports = logById
