const GraphQLObjectType = require('graphql').GraphQLObjectType
const cronJobCreate = require('@platform/cronJob/cronJobCreate.mutation')
const cronJobUpdate = require('@platform/cronJob/cronJobUpdate.mutation')
const eeAppCreate = require('@ee/eeApp/eeAppCreate.mutation')
const eeAppUpdate = require('@ee/eeApp/eeAppUpdate.mutation')
const eeAssetCreate = require('@ee/eeAsset/eeAssetCreate.mutation')
const eeAssetUpdate = require('@ee/eeAsset/eeAssetUpdate.mutation')
const eeJiraTicketCreate=require('@ee/eeJiraTicket/eeJiraTicketCreate.mutation')
const eeUserCreate = require('@ee/eeUser/eeUserCreate.mutation')
const eeUserUpdate = require('@ee/eeUser/eeUserUpdate.mutation')
const eeVulnCreate = require('@ee/eeVuln/eeVulnCreate.mutation')
const eeVulnUpdate = require('@ee/eeVuln/eeVulnUpdate.mutation')
const formCreate = require('@ssd/form/formCreate.mutation')
const formUpdate = require('@ssd/form/formUpdate.mutation')
const formQuestionCreate = require('@ssd/formQuestion/formQuestionCreate.mutation')
const formQuestionUpdate = require('@ssd/formQuestion/formQuestionUpdate.mutation')
const formResponseCreate = require('@ssd/formResponse/formResponseCreate.mutation')
const formResponseUpdate = require('@ssd/formResponse/formResponseUpdate.mutation')
const logCreate = require( '@platform/log/logCreate.mutation' )
const logUpdate=require('@platform/log/logUpdate.mutation')
const userCreate = require('@platform/user/userCreate.mutation')
const userUpdate = require('@platform/user/userUpdate.mutation')
const userAuthenticate = require('@platform/user/userAuthenticate.mutation')
const userGroupCreate = require('@platform/userGroup/userGroupCreate.mutation')
const userGroupUpdate = require('@platform/userGroup/userGroupUpdate.mutation')

const mutations = new GraphQLObjectType({
  name: "mutations",
  fields: {
    cronJobCreate: cronJobCreate,
    cronJobUpdate: cronJobUpdate,
    eeAppCreate: eeAppCreate,
    eeAppUpdate: eeAppUpdate,
    eeAssetCreate: eeAssetCreate,
    eeAssetUpdate: eeAssetUpdate,
    eeUserCreate: eeUserCreate,
    eeUserUpdate: eeUserUpdate,
    eeVulnCreate: eeVulnCreate,
    eeVulnUpdate: eeVulnUpdate,
    formCreate: formCreate,
    formUpdate:formUpdate,
    formQuestionCreate: formQuestionCreate,
    formQuestionUpdate: formQuestionUpdate,
    formResponseCreate: formResponseCreate,
    formResponseUpdate:formResponseUpdate,
    logCreate: logCreate,
    logUpdate: logUpdate,
    userAuthenticate: userAuthenticate,
    userCreate: userCreate,
    userUpdate: userUpdate,
    userGroupCreate: userGroupCreate,
    userGroupUpdate: userGroupUpdate,
    eeJiraTicketCreate:eeJiraTicketCreate
  },
});

module.exports = mutations
